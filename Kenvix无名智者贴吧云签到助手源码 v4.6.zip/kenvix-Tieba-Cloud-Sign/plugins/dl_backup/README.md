# 特别提示
    Git库下载的插件要去掉文件夹名称【-master】才可以使用，不懂的请到百度网盘下载。
# 插件名称
    数据库自动备份
# 插件版本
Version: `1.2`
# 说明
    自动备份数据库发送到邮箱
# 支持版本
[Tieba-Cloud-Sign](https://github.com/MoeNetwork/Tieba-Cloud-Sign "百度贴吧云签到") `V3.8+`
# 官方网站
[http://www.stus8.com/](http://www.stus8.com/ "百度贴吧云签到官方论坛")