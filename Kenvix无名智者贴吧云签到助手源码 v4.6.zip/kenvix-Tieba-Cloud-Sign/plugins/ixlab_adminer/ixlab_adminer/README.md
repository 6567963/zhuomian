#用于贴吧云签到的Adminer数据库管理器
介绍请看这里：[https://git.oschina.net/fsgmhoward/ixlab_adminer/blob/master/README.md](https://git.oschina.net/fsgmhoward/ixlab_adminer/blob/master/README.md)